@echo off
chcp 65001 >nul
title ComfyUI + MOSS-Image 一键部署
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
echo.
echo 按任意键关闭窗口。
pause >nul
