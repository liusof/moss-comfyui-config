param(
    [switch]$SkipModels,
    [string]$HfBase = 'https://hf-mirror.com/Comfy-Org/MOSS-Image/resolve/main'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $root

Write-Host '=== ComfyUI + MOSS-Image 恢复脚本 ==='

# 1. 虚拟环境
$venv = Join-Path $root '.venv'
$python = Join-Path $venv 'Scripts\python.exe'
if (-not (Test-Path $python)) {
    Write-Host '[1/4] 创建 Python 3.11 虚拟环境'
    $created = $false
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3.11 -m venv $venv
        $created = ($LASTEXITCODE -eq 0)
    }
    if (-not $created) {
        & python -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw '无法创建虚拟环境，请先安装 Python 3.11 并加入 PATH' }
    }
} else {
    Write-Host '[1/4] 复用已有 .venv'
}

$ver = & $python -c "import sys;print('%d.%d' % sys.version_info[:2])"
if ($ver -ne '3.11') { Write-Warning "虚拟环境为 Python $ver，快照验证版本是 3.11" }

# 2. 依赖
Write-Host '[2/4] 安装 PyTorch (CUDA 13.0) 与 ComfyUI 依赖'
& $python -m pip install --upgrade pip
& $python -m pip install torch==2.14.1 torchvision==0.29.1 --index-url https://download.pytorch.org/whl/cu130
& $python -m pip install -r requirements.txt

# 3. 模型
$models = @(
    @{ Path = 'models\diffusion_models\moss_image_sft_int8_convrot.safetensors'; Size = 5413698958 },
    @{ Path = 'models\text_encoders\qwen3.5_9b_w4a8_gptq.safetensors'; Size = 7343591088 },
    @{ Path = 'models\vae\flux2-vae_small.safetensors'; Size = 249521340 }
)

if ($SkipModels) {
    Write-Host '[3/4] 跳过模型下载（-SkipModels）'
} else {
    Write-Host '[3/4] 下载 MOSS-Image 量化权重（共约 12.1GB，支持断点续传）'
    foreach ($m in $models) {
        $out = Join-Path $root $m.Path
        $dir = Split-Path -Parent $out
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        if ((Test-Path $out) -and ((Get-Item $out).Length -eq $m.Size)) {
            Write-Host "  已存在且完整：$($m.Path)"
            continue
        }
        $url = $HfBase + '/' + ($m.Path -replace '\\', '/')
        Write-Host "  下载 $($m.Path)"
        & curl.exe -L -C - --retry 10 --retry-delay 5 --retry-all-errors --progress-bar -o $out $url
        if (-not (Test-Path $out) -or (Get-Item $out).Length -ne $m.Size) {
            throw "下载不完整：$($m.Path)，请重新运行本脚本续传"
        }
    }
}

# 4. 完成
Write-Host '[4/4] 完成。启动命令：'
Write-Host '  .\.venv\Scripts\python.exe main.py --listen 127.0.0.1 --port 8188'
Write-Host '  或双击 start_comfyui.bat'
